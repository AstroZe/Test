const express = require('express');
const path = require('path');
const app = express();
const port = 3000;

let cultPoints = {};
let userPoints = {};

app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  const topCults = Object.entries(cultPoints).sort((a, b) => b[1] - a[1]).slice(0, 10);
  const topUsers = Object.entries(userPoints).sort((a, b) => b[1] - a[1]).slice(0, 10);
  
  res.render('index', { topCults, topUsers });
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

module.exports = { cultPoints, userPoints };
