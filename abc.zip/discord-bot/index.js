const { Client, GatewayIntentBits, Collection, REST, Routes } = require('discord.js');
const fs = require('fs');
const { token, clientId, guildId } = require('./config.json');
const { cultPoints, userPoints } = require('./server'); // Import points from server

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent, GatewayIntentBits.GuildMembers] });

client.commands = new Collection();
const commandFiles = fs.readdirSync('./commands').filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

let userCults = {};
let mainMessageId = null;
let mainChannelId = null;

client.once('ready', () => {
  console.log('Ready!');
});

client.on('interactionCreate', async interaction => {
  if (interaction.isCommand()) {
    const command = client.commands.get(interaction.commandName);

    if (!command) return;

    try {
      await command.execute(interaction, { cultPoints, userPoints, userCults, mainMessageId, mainChannelId, client });
    } catch (error) {
      console.error(error);
      await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
    }
  } else if (interaction.isButton()) {
    const { customId } = interaction;
    if (customId.startsWith('join_')) {
      const cultName = customId.split('join_')[1];
      userCults[interaction.user.id] = cultName;

      await interaction.reply({ content: `You joined ${cultName}!`, ephemeral: true });
    } else if (customId === 'leave_cult') {
      delete userCults[interaction.user.id];

      await interaction.reply({ content: 'You left your cult.', ephemeral: true });
    }
  }
});

const commands = [];
commandFiles.forEach(file => {
  const command = require(`./commands/${file}`);
  commands.push(command.data.toJSON());
});

const rest = new REST({ version: '10' }).setToken(token);

(async () => {
  try {
    console.log('Started refreshing application (/) commands.');

    await rest.put(
      Routes.applicationGuildCommands(clientId, guildId),
      { body: commands },
    );

    console.log('Successfully reloaded application (/) commands.');
  } catch (error) {
    console.error(error);
  }
})();

client.login(token);
