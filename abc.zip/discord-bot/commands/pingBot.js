const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pingbot')
    .setDescription('Add points to your cult and yourself')
    .addIntegerOption(option =>
      option.setName('points')
        .setDescription('Points to add')
        .setRequired(true)),
  async execute(interaction, { cultPoints, userPoints, userCults }) {
    const points = interaction.options.getInteger('points');
    const userId = interaction.user.id;

    if (!userPoints[userId]) {
      userPoints[userId] = 0;
    }
    userPoints[userId] += points;

    const cultName = userCults[userId];
    if (cultName) {
      if (!cultPoints[cultName]) {
        cultPoints[cultName] = 0;
      }
      cultPoints[cultName] += points;
    }

    await interaction.reply({ content: `Added ${points} points to yourself${cultName ? ` and ${cultName}` : ''}!`, ephemeral: true });
  },
};
