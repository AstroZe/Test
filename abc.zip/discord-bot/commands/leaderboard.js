const { SlashCommandBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('Displays the top 10 cults and users'),
  async execute(interaction, { cultPoints, userPoints }) {
    const topCults = Object.entries(cultPoints).sort((a, b) => b[1] - a[1]).slice(0, 10);
    const topUsers = Object.entries(userPoints).sort((a, b) => b[1] - a[1]).slice(0, 10);

    let cultLeaderboard = 'Top 10 Cults:\n';
    topCults.forEach(([cult, points], index) => {
      cultLeaderboard += `${index + 1}. ${cult}: ${points} points\n`;
    });

    let userLeaderboard = 'Top 10 Users:\n';
    topUsers.forEach(([user, points], index) => {
      userLeaderboard += `${index + 1}. <@${user}>: ${points} points\n`;
    });

    await interaction.reply({ content: `${cultLeaderboard}\n${userLeaderboard}`, ephemeral: true });
  },
};
