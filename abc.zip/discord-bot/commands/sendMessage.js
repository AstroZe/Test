const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('send')
    .setDescription('Sends the cult selection message'),
  async execute(interaction, { mainMessageId, mainChannelId }) {
    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('leave_cult')
          .setLabel('Leave Cult')
          .setStyle(ButtonStyle.Danger),
      );

    const message = await interaction.reply({ content: 'Choose your cult.', components: [row], fetchReply: true });

    mainMessageId = message.id;
    mainChannelId = message.channelId;
  },
};
