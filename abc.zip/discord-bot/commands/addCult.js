const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('add')
    .setDescription('Add a cult button')
    .addStringOption(option =>
      option.setName('cult_name')
        .setDescription('The name of the cult')
        .setRequired(true))
    .addRoleOption(option =>
      option.setName('role')
        .setDescription('The role for the cult')
        .setRequired(true)),
  async execute(interaction, { mainMessageId, mainChannelId, client }) {
    const cultName = interaction.options.getString('cult_name');
    const role = interaction.options.getRole('role');

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`join_${cultName}`)
          .setLabel(cultName)
          .setStyle(ButtonStyle.Primary),
      );

    if (mainMessageId && mainChannelId) {
      const channel = client.channels.cache.get(mainChannelId);
      const message = await channel.messages.fetch(mainMessageId);

      const newRow = new ActionRowBuilder(message.components[0])
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`join_${cultName}`)
            .setLabel(cultName)
            .setStyle(ButtonStyle.Primary)
        );

      await message.edit({ components: [newRow] });
    }

    await interaction.reply({ content: `Added cult: ${cultName}`, components: [row] });
  },
};
